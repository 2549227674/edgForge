# EdgeForge M0 X4 short-calibration evidence (2026-08-10)

This evidence bundle seals the authorized X4 W8A8/RK3588/16K/1-core runs.

- `n128/`: successful N=128 build/export evidence. The external 11.7 GB artifact is identified by path, size, and SHA-256 but is not duplicated here.
- `n256/`: failed N=256 build evidence. `build()` returned `-1` on a CUDA out-of-memory error before export.
- Private selected records, rendered calibration bodies, and reconstructed public probe bodies are intentionally excluded. Their aggregate receipts and SHA-256 identities remain in the bundle.
- Logits were not generated and the N-vs-2N comparator was not run because N=256 did not build successfully.

Authoritative interpretation: `docs/m0/06_board_smoke.md` §4.4.
