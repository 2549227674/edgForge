#!/usr/bin/env python3
"""Offline X4 N-vs-2N final-token float32 logits convergence check.

This utility neither imports RKLLM nor generates logits.  A later runner must
provide two ``.npz`` files produced from the same 32 fixed probes.  Each file
must contain ``probe_id`` (32 unique strings) and ``logits`` (float32 array of
shape ``[32, vocabulary]``).  It writes a small content-free result JSON.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


PROBE_COUNT = 32
COSINE_THRESHOLD = 0.999
ARGMAX_MATCH_THRESHOLD = 31


def load_logits(path: Path) -> tuple[list[str], np.ndarray]:
    if not path.is_file():
        raise SystemExit(f"logits input missing: {path}")
    with np.load(path, allow_pickle=False) as data:
        if set(data.files) != {"probe_id", "logits"}:
            raise SystemExit(f"{path} must contain exactly probe_id and logits; got {data.files}")
        probe_ids = [str(item) for item in data["probe_id"].tolist()]
        logits = data["logits"]
    if len(probe_ids) != PROBE_COUNT or len(set(probe_ids)) != PROBE_COUNT:
        raise SystemExit(f"{path} must identify exactly {PROBE_COUNT} unique probes")
    if logits.dtype != np.float32 or logits.ndim != 2 or logits.shape[0] != PROBE_COUNT:
        raise SystemExit(f"{path} logits must be float32 with shape [32, vocabulary]; got {logits.dtype} {logits.shape}")
    if not np.isfinite(logits).all():
        raise SystemExit(f"{path} contains non-finite logits")
    return probe_ids, logits


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--n", type=Path, required=True, help="N=128 logits .npz")
    parser.add_argument("--two-n", type=Path, required=True, help="2N=256 logits .npz")
    parser.add_argument("--probe-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.output.exists():
        raise SystemExit(f"refusing to overwrite result: {args.output}")
    manifest = json.loads(args.probe_manifest.read_text(encoding="utf-8"))
    expected_ids = [probe["probe_id"] for probe in manifest.get("probes", [])]
    if manifest.get("probe_count") != PROBE_COUNT or len(expected_ids) != PROBE_COUNT:
        raise SystemExit("probe manifest does not define the X4 fixed 32 probes")

    n_ids, n_logits = load_logits(args.n)
    two_n_ids, two_n_logits = load_logits(args.two_n)
    if set(n_ids) != set(expected_ids) or set(two_n_ids) != set(expected_ids):
        raise SystemExit("logits probe identities do not match the fixed manifest")
    order = {probe_id: index for index, probe_id in enumerate(n_ids)}
    second_order = {probe_id: index for index, probe_id in enumerate(two_n_ids)}
    n_logits = np.stack([n_logits[order[probe_id]] for probe_id in expected_ids])
    two_n_logits = np.stack([two_n_logits[second_order[probe_id]] for probe_id in expected_ids])
    if n_logits.shape != two_n_logits.shape:
        raise SystemExit(f"vocabulary shapes differ: {n_logits.shape} vs {two_n_logits.shape}")

    n_norm = np.linalg.norm(n_logits, axis=1)
    two_n_norm = np.linalg.norm(two_n_logits, axis=1)
    if np.any(n_norm == 0) or np.any(two_n_norm == 0):
        raise SystemExit("zero-norm logits row; convergence cannot be judged")
    cosine = np.sum(n_logits * two_n_logits, axis=1) / (n_norm * two_n_norm)
    argmax_match = np.argmax(n_logits, axis=1) == np.argmax(two_n_logits, axis=1)
    average_cosine = float(np.mean(cosine))
    matching_argmax = int(np.sum(argmax_match))
    passed = average_cosine >= COSINE_THRESHOLD and matching_argmax >= ARGMAX_MATCH_THRESHOLD
    result = {
        "schema": "edgeforge-x4-logits-convergence/v1",
        "N": 128,
        "two_N": 256,
        "probe_count": PROBE_COUNT,
        "input_contract": "same fixed non-private probes; final-token float32 logits; same W8A8/16K settings",
        "thresholds": {
            "mean_cosine_similarity_gte": COSINE_THRESHOLD,
            "argmax_matches_gte": ARGMAX_MATCH_THRESHOLD,
        },
        "observed": {
            "mean_cosine_similarity": average_cosine,
            "argmax_matches": matching_argmax,
            "per_probe_cosine_similarity": {
                probe_id: float(value) for probe_id, value in zip(expected_ids, cosine, strict=True)
            },
            "argmax_match_probe_ids": [
                probe_id for probe_id, match in zip(expected_ids, argmax_match, strict=True) if bool(match)
            ],
        },
        "converged": passed,
        "interpretation": (
            "N=128 may be considered for M2 calibration only when converged is true; "
            "otherwise it is explicitly not a valid M2 calibration scale."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"converged": passed, "mean_cosine": average_cosine, "argmax_matches": matching_argmax}))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
