#!/usr/bin/env python3
"""Read-only identity and isolation gate for a future X5 template trial.

No copy, conversion, board transfer, RKLLM import, or 1-core run occurs here.
The command validates the frozen seven-file source and, when supplied, a
future isolated input directory whose only permitted identity change is the
declared Jinja template.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


REQUIRED = (
    "model.safetensors",
    "chat_template.jinja",
    "config.json",
    "generation_config.json",
    "tokenizer.json",
    "tokenizer_config.json",
    "processor_config.json",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def expected_files(path: Path) -> dict[str, str]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    files = payload.get("files")
    if payload.get("schema_version") != 1 or not isinstance(files, dict) or set(files) != set(REQUIRED):
        raise SystemExit("frozen input manifest does not define exactly the seven required files")
    return {name: str(files[name]) for name in REQUIRED}


def verify(directory: Path, expected: dict[str, str], *, label: str) -> dict[str, str]:
    if not directory.is_dir():
        raise SystemExit(f"{label} is not a directory: {directory}")
    actual = {}
    for name in REQUIRED:
        path = directory / name
        if not path.is_file():
            raise SystemExit(f"{label} missing required file: {path}")
        actual[name] = sha256(path)
        if actual[name] != expected[name]:
            raise SystemExit(f"{label} frozen SHA mismatch: {name}")
    return actual


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--frozen-source", type=Path, required=True)
    parser.add_argument("--frozen-manifest", type=Path, required=True)
    parser.add_argument("--variant-manifest", type=Path, required=True)
    parser.add_argument("--variant-id")
    parser.add_argument("--isolated-input", type=Path)
    parser.add_argument("--artifact-output", type=Path)
    parser.add_argument("--board-output")
    parser.add_argument("--log-output", type=Path)
    parser.add_argument("--allow-nonfrozen-input", action="store_true")
    parser.add_argument("--input-identity-note")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    frozen_source = args.frozen_source.resolve()
    expected = expected_files(args.frozen_manifest)
    source_actual = verify(frozen_source, expected, label="frozen source")
    variants = json.loads(args.variant_manifest.read_text(encoding="utf-8"))
    variant_table = {item["variant_id"]: item for item in variants.get("variants", [])}
    result: dict[str, object] = {
        "mode": "source_identity_only" if not args.variant_id else "future_trial_preflight",
        "frozen_source": str(frozen_source),
        "source_identity": source_actual,
        "no_mutation_performed": True,
    }
    if not args.variant_id:
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    if args.variant_id not in variant_table:
        raise SystemExit(f"unknown X5 variant: {args.variant_id}")
    if not all((args.isolated_input, args.artifact_output, args.board_output, args.log_output)):
        raise SystemExit("variant preflight requires isolated input, artifact, board, and log destinations")
    if not args.allow_nonfrozen_input or not args.input_identity_note:
        raise SystemExit("X5 variant requires explicit --allow-nonfrozen-input and --input-identity-note")
    isolated = args.isolated_input.resolve()
    if isolated == frozen_source or frozen_source in isolated.parents:
        raise SystemExit("isolated input must be outside the frozen source directory")
    if not (isolated / "NOT_FROZEN").is_file():
        raise SystemExit("isolated input must carry its own NOT_FROZEN marker")
    if args.artifact_output.resolve().is_relative_to(frozen_source) or args.log_output.resolve().is_relative_to(frozen_source):
        raise SystemExit("artifact/log destinations must be outside the frozen source directory")
    variant = variant_table[args.variant_id]
    isolated_expected = dict(expected)
    isolated_expected["chat_template.jinja"] = variant["template_sha256"]
    isolated_actual = verify(isolated, isolated_expected, label="isolated X5 input")
    result.update(
        variant_id=args.variant_id,
        input_identity_note=args.input_identity_note,
        isolated_input=str(isolated),
        isolated_identity=isolated_actual,
        artifact_output=str(args.artifact_output.resolve()),
        board_output=args.board_output,
        log_output=str(args.log_output.resolve()),
        runtime_contract={
            "quantized_dtype": "w8a8",
            "target_platform": "RK3588",
            "max_context": 16384,
            "num_npu_core": 1,
        },
    )
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
