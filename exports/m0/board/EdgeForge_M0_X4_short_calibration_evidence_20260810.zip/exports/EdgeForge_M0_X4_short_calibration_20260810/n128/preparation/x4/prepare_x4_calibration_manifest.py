#!/usr/bin/env python3
"""Prepare X4's content-free, deterministic 128/256 calibration manifests.

This is deliberately a read-only preparation utility.  It renders the local
``mix_records`` pool with the frozen Gate-7 contract, but writes only record
identity, counts, flags, and SHA-256 values.  It never writes rendered text,
temporary calibration JSON, an RKLLM artifact, or a model export.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path
from typing import Any, Iterable


TARGET_TOKENS = 827
MAX_CONTEXT = 16_384
COUNTS = (128, 256)
# Measured from the frozen Gemma tokenizer vocabulary: its longest single
# decoded vocabulary entry is 93 UTF-8 bytes.  This supplies a safe pre-token
# lower bound for the known multi-megabyte rendered outliers.
MAX_VOCAB_TOKEN_UTF8_BYTES = 93
CHANNEL_MARKERS = {
    "thought": "<|channel>thought",
    "tool_call": "<|tool_call>",
    "tool_response": "<|tool_response>",
}


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def count_tokens(tokenizer: Any, text: str) -> int:
    return len(tokenizer(text, add_special_tokens=False)["input_ids"])


def bounded_ranking_token_count(tokenizer: Any, text: str) -> tuple[int, bool]:
    """Count exactly through 16K and safely lower-bound longer outliers.

    A row represented by 16,385 has a distance of at least 15,558 from the
    target 827.  Once 256 ordinary short rows exist, it cannot affect either
    fixed X4 selection, while avoiding a full encode of the known 4M-token
    outlier in the local source pool.
    """

    if len(text.encode("utf-8")) > (MAX_CONTEXT + 1) * MAX_VOCAB_TOKEN_UTF8_BYTES:
        return MAX_CONTEXT + 1, True
    ids = tokenizer(
        text,
        add_special_tokens=False,
        truncation=True,
        max_length=MAX_CONTEXT + 1,
    )["input_ids"]
    return len(ids), len(ids) == MAX_CONTEXT + 1


def render(tokenizer: Any, record: dict[str, Any]) -> str:
    return tokenizer.apply_chat_template(
        record["messages"],
        tools=record.get("tools") or None,
        tokenize=False,
        add_generation_prompt=False,
        enable_thinking=True,
        preserve_thinking=True,
    )


def truncate_rendered(tokenizer: Any, rendered: str) -> tuple[str, int, bool]:
    """Apply the frozen P5 16K rule and report the actual re-encoded length."""

    ids = tokenizer(rendered, add_special_tokens=False)["input_ids"]
    if len(ids) <= MAX_CONTEXT:
        return rendered, len(ids), False
    clipped = tokenizer.decode(
        ids[:MAX_CONTEXT], skip_special_tokens=False, clean_up_tokenization_spaces=False
    )
    reencoded_count = count_tokens(tokenizer, clipped)
    if reencoded_count > MAX_CONTEXT:
        raise RuntimeError(
            f"tokenizer round-trip exceeded X4 cap: {reencoded_count} > {MAX_CONTEXT}"
        )
    return clipped, reencoded_count, True


def decontamination_status(record: dict[str, Any]) -> str:
    provenance = record.get("provenance")
    if not isinstance(provenance, dict):
        return "provenance_missing"
    rules = provenance.get("redaction_rules")
    if isinstance(rules, list):
        return "rules:" + ",".join(sorted(map(str, rules))) if rules else "rules:empty"
    return "rules:absent" if rules is None else "rules:" + str(rules)


def iter_records(root: Path) -> Iterable[tuple[Path, int, dict[str, Any]]]:
    for path in sorted(root.glob("*.jsonl")):
        with path.open("r", encoding="utf-8") as source:
            for line_number, line in enumerate(source, 1):
                if line.strip():
                    yield path, line_number, json.loads(line)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mix-records", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not args.mix_records.is_dir():
        raise SystemExit(f"mix_records directory is missing: {args.mix_records}")
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        raise SystemExit(f"refusing to overwrite a nonempty output directory: {args.output_dir}")

    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(
        str(args.model), local_files_only=True, trust_remote_code=True
    )
    rows: list[dict[str, Any]] = []
    seen_uids: set[str] = set()
    errors: Counter[str] = Counter()
    source_files = sorted(args.mix_records.glob("*.jsonl"))

    for path, line_number, record in iter_records(args.mix_records):
        try:
            uid = str(record["uid"])
            if uid in seen_uids:
                raise RuntimeError(f"duplicate uid: {uid}")
            seen_uids.add(uid)
            rendered = render(tokenizer, record)
            rendered_tokens, token_count_capped = bounded_ranking_token_count(tokenizer, rendered)
        except Exception as exc:
            errors[type(exc).__name__] += 1
            continue
        row = {
            "uid": uid,
            "dataset": str(record.get("dataset", path.stem)),
            "source_file": path.name,
            "source_line": line_number,
            "rendered_sha256": sha256_bytes(rendered.encode("utf-8")),
            "rendered_tokens": rendered_tokens,
            "rendered_tokens_capped_at_16385": token_count_capped,
            "decontamination_status": decontamination_status(record),
        }
        for channel, marker in CHANNEL_MARKERS.items():
            row[f"{channel}_segments"] = rendered.count(marker)
        rows.append(row)

    if errors:
        raise RuntimeError(f"X4 refused: rendering/identity errors: {dict(errors)}")
    if len(rows) < max(COUNTS):
        raise RuntimeError(f"only {len(rows)} renderable records; need {max(COUNTS)}")

    # Fixed R1.7 ordering: distance from p50=827, then stable UID.  The
    # original rendered token count is the declared ranking measure; the P5
    # truncation rule is applied to selected records before manifesting.
    rows.sort(key=lambda row: (abs(row["rendered_tokens"] - TARGET_TOKENS), row["uid"]))
    selected = rows[: max(COUNTS)]
    if any(row["rendered_tokens_capped_at_16385"] for row in selected):
        raise RuntimeError("X4 selection unexpectedly contains a capped token count")
    selected_by_uid = {row["uid"]: row for row in selected}
    rendered_selected: dict[str, str] = {}
    for _, _, record in iter_records(args.mix_records):
        uid = str(record["uid"])
        if uid in selected_by_uid:
            rendered_selected[uid] = render(tokenizer, record)
    if set(rendered_selected) != set(selected_by_uid):
        raise RuntimeError("could not re-read every selected X4 UID")

    for rank, row in enumerate(selected, 1):
        clipped, calibration_tokens, truncated = truncate_rendered(
            tokenizer, rendered_selected[row["uid"]]
        )
        row.update(
            selection_rank=rank,
            calibration_tokens=calibration_tokens,
            truncated_to_max_context=truncated,
            calibration_sha256=sha256_bytes(clipped.encode("utf-8")),
            selected_for_n128=rank <= 128,
            selected_for_n256=True,
        )

    totals = {
        str(count): sum(row["calibration_tokens"] for row in selected[:count])
        for count in COUNTS
    }
    if not 85_000 <= totals["128"] <= 125_000:
        raise RuntimeError(
            f"X4 128 sample token gate failed: {totals['128']} not in [85000, 125000]"
        )

    args.output_dir.mkdir(parents=True)
    fields = [
        "selection_rank", "uid", "dataset", "source_file", "source_line",
        "rendered_sha256", "rendered_tokens", "calibration_sha256",
        "rendered_tokens_capped_at_16385", "calibration_tokens", "truncated_to_max_context", "thought_segments",
        "tool_call_segments", "tool_response_segments", "decontamination_status",
        "selected_for_n128", "selected_for_n256",
    ]
    for count in COUNTS:
        path = args.output_dir / f"x4_calibration_manifest_{count}.tsv"
        with path.open("w", encoding="utf-8") as output:
            output.write("\t".join(fields) + "\n")
            for row in selected[:count]:
                output.write("\t".join(str(row[field]) for field in fields) + "\n")

    summary = {
        "schema": "edgeforge-x4-calibration-preparation/v1",
        "purpose": "Preparation only; no build, export, logits, or calibration text output.",
        "selection": {
            "fixed_rule": "sort all rendered records by abs(token_count - 827), then stable uid; select nested 128/256",
            "target_p50_tokens": TARGET_TOKENS,
            "counts": list(COUNTS),
            "token_totals_after_truncation": totals,
            "n128_valid_for_build": True,
            "truncation_rule": "retain first 16384 tokenizer IDs, decode with special tokens retained, re-encode and record actual calibration_tokens",
            "ranking_count_guard": "counts through 16384 are exact; a 16385 value is a lower-bound sentinel for a longer record and cannot enter the selected 256 near token target 827",
            "max_vocab_token_utf8_bytes": MAX_VOCAB_TOKEN_UTF8_BYTES,
            "truncated_counts": {
                str(count): sum(row["truncated_to_max_context"] for row in selected[:count])
                for count in COUNTS
            },
        },
        "render_contract": {
            "model_dir": str(args.model),
            "tokenizer_class": type(tokenizer).__name__,
            "chat_template_sha256": sha256_file(args.model / "chat_template.jinja"),
            "tokenizer_json_sha256": sha256_file(args.model / "tokenizer.json"),
            "options": {
                "add_generation_prompt": False,
                "enable_thinking": True,
                "preserve_thinking": True,
            },
        },
        "source_pool": {
            "path": str(args.mix_records),
            "files": {
                path.name: {"bytes": path.stat().st_size, "sha256": sha256_file(path)}
                for path in source_files
            },
            "records_rendered": len(rows),
        },
        "manifest_contains": "identity, source position, counts, flags, and hashes only; no record or rendered body",
    }
    (args.output_dir / "x4_calibration_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({"records_rendered": len(rows), "token_totals": totals}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
