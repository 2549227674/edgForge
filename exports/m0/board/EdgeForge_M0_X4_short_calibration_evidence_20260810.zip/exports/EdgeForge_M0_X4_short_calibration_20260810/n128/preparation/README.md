# EdgeForge M0 X4/X5 preparation package (2026-08-09)

This package records preparation only.  It contains neither `mix_records` body
text nor rendered calibration text, no model copy or artifact, no logits, and
no board/cloud execution log.

## Contents

- `x4/generated/`: nested 128/256 content-free calibration manifests and their
  summary.  N=128 totals 105,865 tokens (valid pre-build gate); 2N=256 totals
  211,725 tokens; neither selection needs 16K truncation.
- `x4/x4_public_probe_identity.json`: identity and hashes for 32 fixed public
  MMLU probes, without prompt bodies.
- `x4/compare_n_vs_2n_logits.py`: an offline consumer for future final-token
  float32 logits only; it does not call RKLLM or generate logits.
- `x5/`: a minimal Jinja syntax sequence, isolated naming contract, and the
  source/isolated seven-file preflight gate.  No isolated input has been made.

## Guardrails

- X4 requires the frozen W8A8 / 16K rendering contract and no build until the
  selected manifest is revalidated.
- X5 requires an isolated `NOT_FROZEN` directory and explicit identity note;
  the frozen `models/gemma-4-E4B-it` directory must remain unchanged.
- §8.5 owner decision is A: 3-core is handed to M2 without redefining 1-core
  as the locked delivery form.

Final interpretation and the non-execution boundary are frozen in
`docs/m0/06_board_smoke.md` §4.4–§5.
