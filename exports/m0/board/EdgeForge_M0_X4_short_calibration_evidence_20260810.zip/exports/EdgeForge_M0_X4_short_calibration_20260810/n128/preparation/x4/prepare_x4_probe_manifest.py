#!/usr/bin/env python3
"""Create X4's fixed 32-probe identity manifest without writing probe bodies.

The probes are public MMLU rows already pinned by ``mmlu_fast_500.json``.  The
manifest gives a later isolated logits runner enough information to reconstruct
each prompt from the local parquet shard and reject any row/prompt drift.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


PROMPT_FORMAT = "edgeforge-x4-mmlu-zero-shot/v1"
LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_hash(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def prompt_for_row(row: dict[str, Any]) -> str:
    choices = row["choices"]
    if len(choices) > len(LETTERS):
        raise ValueError(f"too many choices: {len(choices)}")
    answer_lines = "\n".join(f"{LETTERS[index]}. {choice}" for index, choice in enumerate(choices))
    return f"Question: {row['question']}\n{answer_lines}\nAnswer:"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fast-manifest", type=Path, required=True)
    parser.add_argument("--mmlu-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.output.exists():
        raise SystemExit(f"refusing to overwrite existing probe manifest: {args.output}")
    from pyarrow import parquet as pq

    frozen = json.loads(args.fast_manifest.read_text(encoding="utf-8"))
    if frozen.get("dataset") != "cais/mmlu" or frozen.get("schema_version") != "1.0":
        raise SystemExit("unexpected MMLU frozen-manifest identity")
    entries = frozen.get("selected")
    if not isinstance(entries, list):
        raise SystemExit("MMLU frozen manifest lacks selected rows")

    by_subject: dict[str, list[dict[str, Any]]] = {}
    for entry in entries:
        by_subject.setdefault(str(entry["subject"]), []).append(entry)
    subjects = sorted(by_subject)
    if len(subjects) < 32:
        raise SystemExit(f"only {len(subjects)} selected MMLU subjects; need 32")

    probes: list[dict[str, Any]] = []
    source_files: dict[str, dict[str, Any]] = {}
    for probe_number, subject in enumerate(subjects[:32], 1):
        entry = min(by_subject[subject], key=lambda item: int(item["doc_id"]))
        doc_id = int(entry["doc_id"])
        source = args.mmlu_root / subject / "test-00000-of-00001.parquet"
        rows = pq.read_table(source).to_pylist()
        if not 0 <= doc_id < len(rows):
            raise SystemExit(f"doc_id {doc_id} outside {source}")
        row = rows[doc_id]
        row_sha = canonical_hash(row)
        if row_sha != entry["row_sha256"]:
            raise SystemExit(f"frozen row hash mismatch for {subject}:{doc_id}")
        prompt = prompt_for_row(row)
        source_rel = source.as_posix()
        source_files[source_rel] = {"sha256": sha256_file(source), "bytes": source.stat().st_size}
        probes.append(
            {
                "probe_id": f"x4_mmlu_{probe_number:02d}_{subject}_{doc_id}",
                "public_source": "cais/mmlu",
                "revision": frozen["revision"],
                "split": "test",
                "subject": subject,
                "doc_id": doc_id,
                "source_row_sha256": row_sha,
                "prompt_format": PROMPT_FORMAT,
                "prompt_sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
                "prompt_utf8_bytes": len(prompt.encode("utf-8")),
            }
        )

    payload = {
        "schema": "edgeforge-x4-public-probe-identity/v1",
        "purpose": "Fixed, non-private 32-probe identity only; bodies are intentionally not stored.",
        "probe_count": len(probes),
        "selection": "lexicographically first 32 MMLU subjects in manifests/mmlu_fast_500.json; smallest frozen doc_id per subject",
        "prompt_reconstruction": {
            "format": PROMPT_FORMAT,
            "definition": "Question: {question}\\nA. {choice0} ...\\nAnswer:",
            "choice_labels": LETTERS,
            "source_manifest": str(args.fast_manifest),
            "source_manifest_sha256": sha256_file(args.fast_manifest),
            "source_files": source_files,
        },
        "probes": probes,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({"probe_count": len(probes), "output": str(args.output)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
