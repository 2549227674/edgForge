"""Verify the seven-file frozen HF identity required for RKLLM experiments."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MANIFEST = ROOT / "manifests/gemma4_e4b_rkllm_frozen_input_sha256.json"
REQUIRED_FILENAMES = frozenset(
    {
        "model.safetensors",
        "chat_template.jinja",
        "config.json",
        "generation_config.json",
        "tokenizer.json",
        "tokenizer_config.json",
        "processor_config.json",
    }
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_manifest(path: Path) -> tuple[str, dict[str, str]]:
    if not path.is_file():
        raise SystemExit(f"frozen-input manifest is missing: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"invalid frozen-input manifest: {path}") from exc
    if payload.get("schema_version") != 1:
        raise SystemExit(f"unsupported frozen-input manifest schema: {path}")
    identity = payload.get("identity")
    files = payload.get("files")
    if not isinstance(identity, str) or not isinstance(files, dict):
        raise SystemExit(f"frozen-input manifest lacks identity or files: {path}")
    if set(files) != REQUIRED_FILENAMES or not all(
        isinstance(value, str) and len(value) == 64 for value in files.values()
    ):
        raise SystemExit(f"frozen-input manifest must define exactly the required seven hashes: {path}")
    return identity, files


def verify_frozen_input(
    model: Path,
    *,
    manifest_path: Path = DEFAULT_MANIFEST,
    allow_nonfrozen_input: bool = False,
    input_identity_note: str | None = None,
) -> dict[str, object]:
    """Return auditable identity details or refuse a mutable/incorrect input."""

    if not model.is_dir():
        raise SystemExit(f"model directory is missing: {model}")
    marker = model / "NOT_FROZEN"
    if marker.exists() and not allow_nonfrozen_input:
        raise SystemExit(
            f"model directory is explicitly marked NOT_FROZEN: {marker}; "
            "use an isolated verified copy instead"
        )
    if allow_nonfrozen_input:
        if not input_identity_note or not input_identity_note.strip():
            raise SystemExit("--allow-nonfrozen-input requires --input-identity-note")
        return {
            "status": "bypassed_nonfrozen_input",
            "model": str(model),
            "marker_present": marker.exists(),
            "note": input_identity_note.strip(),
        }

    identity, expected = _load_manifest(manifest_path)
    missing = [name for name in sorted(REQUIRED_FILENAMES) if not (model / name).is_file()]
    if missing:
        raise SystemExit(f"frozen input is missing required files: {', '.join(missing)}")
    actual = {name: sha256(model / name) for name in sorted(REQUIRED_FILENAMES)}
    mismatches = [
        f"{name}: expected {expected[name]}, got {actual[name]}"
        for name in sorted(REQUIRED_FILENAMES)
        if actual[name] != expected[name]
    ]
    if mismatches:
        raise SystemExit("frozen input SHA-256 mismatch; refusing conversion: " + "; ".join(mismatches))
    return {
        "status": "verified_frozen_input",
        "identity": identity,
        "manifest": str(manifest_path),
        "manifest_sha256": sha256(manifest_path),
        "source_sha256": actual,
    }
