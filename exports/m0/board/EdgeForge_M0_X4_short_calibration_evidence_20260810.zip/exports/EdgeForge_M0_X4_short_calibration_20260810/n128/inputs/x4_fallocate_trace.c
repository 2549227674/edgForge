/* Run-scoped X4 diagnostic: record fallocate calls without changing RKLLM. */
#define _GNU_SOURCE

#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/types.h>
#include <unistd.h>

typedef int (*fallocate_fn)(int, int, off_t, off_t);
typedef int (*fallocate64_fn)(int, int, off64_t, off64_t);

static __thread int tracing;

static void record_call(int fd, int mode, off_t offset, off_t length, int result, int saved_errno) {
    const char *log_path = getenv("X4_FALLOCATE_TRACE_LOG");
    if (log_path == NULL || tracing) {
        return;
    }
    tracing = 1;
    char link_path[64];
    char target[PATH_MAX + 1];
    int link_length = snprintf(link_path, sizeof(link_path), "/proc/self/fd/%d", fd);
    ssize_t target_length = link_length > 0 ? readlink(link_path, target, PATH_MAX) : -1;
    if (target_length >= 0) {
        target[target_length] = '\0';
    } else {
        strcpy(target, "<unresolved>");
    }
    int log_fd = open(log_path, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0600);
    if (log_fd >= 0) {
        struct stat file_status;
        struct statvfs filesystem_status;
        struct rlimit file_size_limit;
        int have_file_status = fstat(fd, &file_status) == 0;
        int have_filesystem_status = fstatvfs(fd, &filesystem_status) == 0;
        int have_file_size_limit = getrlimit(RLIMIT_FSIZE, &file_size_limit) == 0;
        dprintf(log_fd,
                "pid=%ld uid=%ld fd=%d path=%s mode=%d offset=%lld length=%lld result=%d errno=%d"
                " file_size=%lld file_blocks_512=%lld fs_bavail=%llu fs_frsize=%lu"
                " rlimit_fsize_cur=%llu rlimit_fsize_max=%llu\n",
                (long)getpid(), (long)getuid(), fd, target, mode,
                (long long)offset, (long long)length, result, saved_errno,
                (long long)(have_file_status ? file_status.st_size : -1),
                (long long)(have_file_status ? file_status.st_blocks : -1),
                (unsigned long long)(have_filesystem_status ? filesystem_status.f_bavail : 0),
                (unsigned long)(have_filesystem_status ? filesystem_status.f_frsize : 0),
                (unsigned long long)(have_file_size_limit ? file_size_limit.rlim_cur : 0),
                (unsigned long long)(have_file_size_limit ? file_size_limit.rlim_max : 0));
        close(log_fd);
    }
    tracing = 0;
}

int fallocate(int fd, int mode, off_t offset, off_t length) {
    static fallocate_fn real_fallocate;
    if (real_fallocate == NULL) {
        real_fallocate = (fallocate_fn)dlsym(RTLD_NEXT, "fallocate");
    }
    if (real_fallocate == NULL) {
        errno = ENOSYS;
        record_call(fd, mode, offset, length, -1, errno);
        return -1;
    }
    int result = real_fallocate(fd, mode, offset, length);
    int saved_errno = errno;
    record_call(fd, mode, offset, length, result, saved_errno);
    errno = saved_errno;
    return result;
}

int fallocate64(int fd, int mode, off64_t offset, off64_t length) {
    static fallocate64_fn real_fallocate64;
    if (real_fallocate64 == NULL) {
        real_fallocate64 = (fallocate64_fn)dlsym(RTLD_NEXT, "fallocate64");
    }
    if (real_fallocate64 == NULL) {
        errno = ENOSYS;
        record_call(fd, mode, (off_t)offset, (off_t)length, -1, errno);
        return -1;
    }
    int result = real_fallocate64(fd, mode, offset, length);
    int saved_errno = errno;
    record_call(fd, mode, (off_t)offset, (off_t)length, result, saved_errno);
    errno = saved_errno;
    return result;
}
