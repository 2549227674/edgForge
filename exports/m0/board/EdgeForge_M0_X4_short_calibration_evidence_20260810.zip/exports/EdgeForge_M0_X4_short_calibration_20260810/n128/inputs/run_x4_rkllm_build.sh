#!/usr/bin/env bash
# Run one isolated X4 W8A8/RK3588/16K/1-core conversion with audit logs.
# Usage: run_x4_rkllm_build.sh RUN_DIR PYTHON MODEL DATASET FROZEN_MANIFEST
set -uo pipefail

if [ "$#" -ne 5 ]; then
  printf '%s\n' "usage: $0 RUN_DIR PYTHON MODEL DATASET FROZEN_MANIFEST" >&2
  exit 64
fi

run_dir=$1
python_bin=$2
model_dir=$3
dataset=$4
frozen_manifest=$5
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
converter="$script_dir/convert_gemma4_e4b_rkllm_smoke.py"
identity="$script_dir/rkllm_input_identity.py"
# X4 normally keeps the artifact under the run directory.  A run-scoped,
# absolute alternate location is permitted only to isolate an exporter from a
# filesystem quota on the audit-log volume; the wrapper still records its SHA
# beside the logs.  Never accept a relative override, which would make the
# output location ambiguous in the evidence record.
artifact=${X4_ARTIFACT_PATH:-"$run_dir/artifact.rkllm"}
case "$artifact" in
  /*) ;;
  *)
    printf 'X4_ARTIFACT_PATH must be absolute when set: %s\n' "$artifact" >&2
    exit 64
    ;;
esac

for required in "$python_bin" "$model_dir" "$dataset" "$frozen_manifest" "$converter" "$identity"; do
  if [ ! -e "$required" ]; then
    printf 'missing required X4 input: %s\n' "$required" >&2
    exit 66
  fi
done
if [ -e "$run_dir" ]; then
  printf 'refusing to reuse X4 run directory: %s\n' "$run_dir" >&2
  exit 73
fi
if [ -e "$artifact" ]; then
  printf 'refusing to overwrite X4 artifact path: %s\n' "$artifact" >&2
  exit 73
fi
mkdir -p "$run_dir"
mkdir -p "$(dirname -- "$artifact")"

printf '%s\n' $'timestamp_epoch_s\tpid\tvm_rss_kib\tvm_hwm_kib\tgpu_used_mib' > "$run_dir/resource_monitor.tsv"
sample_resources() {
  sample_pid=$1
  sample_out=$2
  while kill -0 "$sample_pid" 2>/dev/null; do
    sample_ts=$(date +%s.%N)
    sample_rss=$(awk '/^VmRSS:/ {print $2}' "/proc/$sample_pid/status" 2>/dev/null || true)
    sample_hwm=$(awk '/^VmHWM:/ {print $2}' "/proc/$sample_pid/status" 2>/dev/null || true)
    sample_gpu=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits 2>/dev/null | awk '{sum += $1} END {if (NR) print sum; else print "NA"}')
    printf '%s\t%s\t%s\t%s\t%s\n' "${sample_ts:-NA}" "$sample_pid" "${sample_rss:-NA}" "${sample_hwm:-NA}" "${sample_gpu:-NA}" >> "$sample_out"
    sleep 1
  done
}

start_epoch=$(date +%s.%N)
"$python_bin" "$converter" \
  --model "$model_dir" \
  --dataset "$dataset" \
  --output "$artifact" \
  --device cuda \
  --dtype bfloat16 \
  --max-context 16384 \
  --num-npu-core 1 \
  --quantized-dtype w8a8 \
  --frozen-input-manifest "$frozen_manifest" \
  > "$run_dir/stdout" 2> "$run_dir/stderr" &
build_pid=$!
sample_resources "$build_pid" "$run_dir/resource_monitor.tsv" &
monitor_pid=$!
wait "$build_pid"
build_exit=$?
wait "$monitor_pid" || true
end_epoch=$(date +%s.%N)

"$python_bin" - "$start_epoch" "$end_epoch" "$build_exit" "$run_dir/run_result.json" <<'PY'
import json
import sys

started, ended, exit_code, output = sys.argv[1:]
payload = {
    "schema": "edgeforge-x4-build-run/v1",
    "contract": {
        "quantized_dtype": "w8a8",
        "target_platform": "RK3588",
        "max_context": 16384,
        "num_npu_core": 1,
        "device": "cuda",
        "dtype": "bfloat16",
    },
    "started_epoch_s": float(started),
    "ended_epoch_s": float(ended),
    "wall_seconds": float(ended) - float(started),
    "exit_code": int(exit_code),
}
with open(output, "w", encoding="utf-8") as handle:
    json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
    handle.write("\n")
PY

sha256sum "$converter" "$identity" "$dataset" "$frozen_manifest" > "$run_dir/input_sha256.txt"
if [ -f "$artifact" ]; then
  sha256sum "$artifact" > "$run_dir/artifact.sha256"
fi
printf 'build_exit_code=%s\n' "$build_exit" > "$run_dir/exit_code"
exit "$build_exit"
