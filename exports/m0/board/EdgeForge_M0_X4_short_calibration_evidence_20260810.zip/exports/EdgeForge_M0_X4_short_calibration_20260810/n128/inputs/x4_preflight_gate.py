#!/usr/bin/env python3
"""Write a content-safe verification record before an isolated X4 build.

This program deliberately never prints calibration inputs or ``mix_records``
content.  It only validates immutable identities, counts, and SHA-256 values
needed by the R1.7 X4 contract.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import time
from pathlib import Path
from typing import Any


FROZEN_FILES = {
    "model.safetensors": "cfbd3d2f1cd71bd471c37fe2bf8546d5028d41e5736f64e1ca6c6b8893125503",
    "chat_template.jinja": "0a2c8073c878ab1da004bee933a998606537bbb62016310352c7285c3f01c5b5",
    "config.json": "33b10c02df3c2e8536cf323d29d53262aaa2f4d11dbe19bc729373fbe90295d4",
    "generation_config.json": "d4226bbe3117d2d253ba4609720ba82c6c4ce4627a9a6ae05387c78983ac03de",
    "tokenizer.json": "cc8d3a0ce36466ccc1278bf987df5f71db1719b9ca6b4118264f45cb627bfe0f",
    "tokenizer_config.json": "90c3a3ba5bf53818383a58e1a776cbcacd2a038d4812eaa373e1522f2d06f3df",
    "processor_config.json": "32bdf45d2ad4cc29a0822ddd157a182de76644f0419a6228d151495256e9813c",
}
N128_SHA = "d41e4d6105edb9b6a64e747f3258b1cc9d73ef9a7cf9cba0bc4d4a25ba44af10"
N256_SHA = "116732cdf0273cc5e2d2712b52c93a14308963e542eed4b7c3b01198011726df"
N128_TOKENS = 105_865
N256_TOKENS = 211_725


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as source:
        return json.load(source, object_pairs_hook=reject_duplicate_keys)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--frozen-model", type=Path, required=True)
    parser.add_argument("--frozen-manifest", type=Path, required=True)
    parser.add_argument("--preparation", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as source:
        rows = list(csv.DictReader(source, delimiter="\t"))
    if not rows:
        raise ValueError(f"empty manifest: {path}")
    return rows


def validate_manifest(rows: list[dict[str, str]], expected_count: int, expected_tokens: int) -> None:
    required = {
        "selection_rank", "uid", "rendered_sha256", "calibration_sha256",
        "calibration_tokens", "truncated_to_max_context", "selected_for_n128",
        "selected_for_n256",
    }
    if len(rows) != expected_count or not required <= set(rows[0]):
        raise ValueError("manifest shape or required fields do not match X4 contract")
    if [row["selection_rank"] for row in rows] != [str(i) for i in range(1, expected_count + 1)]:
        raise ValueError("manifest selection ranks are not the frozen sequence")
    if len({row["uid"] for row in rows}) != expected_count:
        raise ValueError("manifest UIDs are not unique")
    if sum(int(row["calibration_tokens"]) for row in rows) != expected_tokens:
        raise ValueError("manifest token total does not match the X4 contract")
    if any(row["truncated_to_max_context"] != "False" for row in rows):
        raise ValueError("X4 manifests must record zero truncations")
    if any(row["selected_for_n256"] != "True" for row in rows):
        raise ValueError("manifest does not preserve the fixed N=256 membership")
    if expected_count == 128 and any(row["selected_for_n128"] != "True" for row in rows):
        raise ValueError("N=128 manifest does not preserve the fixed membership")


def validate_root_manifest(preparation: Path) -> int:
    listing = preparation / "manifest.sha256"
    lines = listing.read_text(encoding="utf-8").splitlines()
    if not lines:
        raise ValueError("empty preparation root manifest")
    for line in lines:
        expected, relative = line.split(maxsplit=1)
        target = preparation / relative.removeprefix("./")
        if not target.is_file() or sha256_file(target) != expected:
            raise ValueError(f"preparation root manifest mismatch: {relative}")
    return len(lines)


def main() -> int:
    args = parse_args()
    if args.output.exists():
        raise SystemExit(f"refusing to overwrite X4 gate output: {args.output}")
    if (args.frozen_model / "NOT_FROZEN").exists():
        raise SystemExit("refusing NOT_FROZEN model directory")
    manifest = load_json(args.frozen_manifest)
    if manifest.get("files") != FROZEN_FILES:
        raise SystemExit("frozen input manifest does not match the seven-file R1.7 baseline")
    for name, expected in FROZEN_FILES.items():
        if sha256_file(args.frozen_model / name) != expected:
            raise SystemExit(f"frozen input hash mismatch: {name}")

    root_entries = validate_root_manifest(args.preparation)
    n128_path = args.preparation / "x4/generated/x4_calibration_manifest_128.tsv"
    n256_path = args.preparation / "x4/generated/x4_calibration_manifest_256.tsv"
    probes_path = args.preparation / "x4/x4_public_probe_identity.json"
    if sha256_file(n128_path) != N128_SHA or sha256_file(n256_path) != N256_SHA:
        raise SystemExit("X4 calibration manifest hash mismatch")
    rows128, rows256 = read_tsv(n128_path), read_tsv(n256_path)
    validate_manifest(rows128, 128, N128_TOKENS)
    validate_manifest(rows256, 256, N256_TOKENS)
    if rows256[:128] != rows128:
        raise SystemExit("N=128 manifest is not the exact nested prefix of N=256")
    if not (85_000 <= N128_TOKENS <= 125_000):
        raise SystemExit("N=128 token gate is outside its preregistered range")
    probes = load_json(probes_path)
    probe_rows = probes.get("probes")
    if probes.get("probe_count") != 32 or not isinstance(probe_rows, list) or len(probe_rows) != 32:
        raise SystemExit("public probe identity does not contain exactly 32 probes")
    if len({row.get("probe_id") for row in probe_rows}) != 32 or any(
        row.get("public_source") != "cais/mmlu" for row in probe_rows
    ):
        raise SystemExit("public probe identity is invalid")

    receipt = load_json(args.receipt)
    dataset = load_json(args.dataset)
    # The original controlled materialization receipt predates the explicit
    # ``N`` field added to the reusable utility.  Its fixed count, token total,
    # zero-truncation flag, manifest SHA, and ordered calibration hashes still
    # fully bind this N=128 body.  Accept only that narrowly defined legacy
    # form; any conflicting explicit N remains a rejection.
    if receipt.get("N") not in (None, 128) or receipt.get("record_count") != 128:
        raise SystemExit("N=128 dataset receipt has the wrong count")
    if receipt.get("token_total") != N128_TOKENS or receipt.get("truncated_count") != 0:
        raise SystemExit("N=128 dataset receipt has the wrong token or truncation totals")
    if receipt.get("manifest_sha256") != N128_SHA or receipt.get("dataset_sha256") != sha256_file(args.dataset):
        raise SystemExit("N=128 dataset receipt hash binding is invalid")
    if not isinstance(dataset, list) or len(dataset) != 128:
        raise SystemExit("N=128 dataset body has the wrong list length")
    expected_calibration_hashes = [row["calibration_sha256"] for row in rows128]
    if receipt.get("calibration_sha256_in_selection_order") != expected_calibration_hashes:
        raise SystemExit("N=128 receipt sequence does not bind to the bodyless manifest")
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(str(args.frozen_model), local_files_only=True, trust_remote_code=True)
    observed_hashes: list[str] = []
    observed_tokens = 0
    for item in dataset:
        if set(item) != {"input", "target"} or item["target"] != "" or not isinstance(item["input"], str):
            raise SystemExit("N=128 dataset schema differs from the RKLLM contract")
        text = item["input"]
        observed_hashes.append(hashlib.sha256(text.encode("utf-8")).hexdigest())
        observed_tokens += len(tokenizer(text, add_special_tokens=False)["input_ids"])
    if observed_hashes != expected_calibration_hashes or observed_tokens != N128_TOKENS:
        raise SystemExit("N=128 controlled body does not reproduce its manifest identity")

    payload = {
        "schema": "edgeforge-x4-preflight/v1",
        "timestamp_epoch_s": time.time(),
        "frozen_input": {"status": "verified", "file_count": 7, "manifest_sha256": sha256_file(args.frozen_manifest)},
        "preparation": {"root_manifest_entries_verified": root_entries, "n128_manifest_sha256": N128_SHA, "n256_manifest_sha256": N256_SHA, "n128_is_nested_prefix": True},
        "n128": {"records": 128, "tokens": N128_TOKENS, "truncations": 0, "token_gate_85000_to_125000": True, "dataset_sha256": sha256_file(args.dataset), "body_reconstruction_binding": "verified_against_existing_controlled_dataset_and_receipt_without_reading_mix_records", "receipt_N_field": receipt.get("N", "legacy_absent")},
        "public_probes": {"count": 32, "identity_sha256": sha256_file(probes_path)},
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"frozen_files": 7, "root_entries": root_entries, "n128_records": 128, "n128_tokens": N128_TOKENS, "n256_nested": True, "probes": 32}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
