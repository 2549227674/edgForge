#!/usr/bin/env python3
"""Extract only X4's frozen source positions into a private run-scoped subset.

The subset is suitable for transfer to the authorized cloud host.  This tool
never prints record bodies and never modifies the source ``mix_records``.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
from typing import Any


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--mix-records", type=Path, required=True)
    parser.add_argument("--expected-count", type=int, choices=(128, 256), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.output.exists() or args.receipt.exists():
        raise SystemExit("refusing to overwrite an X4 selected subset or receipt")
    with args.manifest.open("r", encoding="utf-8", newline="") as source:
        rows = list(csv.DictReader(source, delimiter="\t"))
    if len(rows) != args.expected_count:
        raise SystemExit("X4 manifest count does not match the requested subset")

    positions: dict[str, dict[int, dict[str, str]]] = {}
    for row in rows:
        positions.setdefault(row["source_file"], {})[int(row["source_line"])] = row
    selected: dict[str, dict[str, Any]] = {}
    for source_name, expected_lines in positions.items():
        source_path = args.mix_records / source_name
        if not source_path.is_file():
            raise SystemExit(f"missing controlled X4 source file: {source_name}")
        remaining = set(expected_lines)
        with source_path.open("r", encoding="utf-8") as source:
            for line_number, line in enumerate(source, 1):
                if line_number not in remaining:
                    continue
                row = expected_lines[line_number]
                record = json.loads(line)
                selected[row["selection_rank"]] = {
                    "selection_rank": row["selection_rank"],
                    "uid": row["uid"],
                    "source_file": source_name,
                    "source_line": line_number,
                    "record": record,
                }
                remaining.remove(line_number)
                if not remaining:
                    break
        if remaining:
            raise RuntimeError(f"X4 source positions are missing in {source_name}")

    payload = [selected[row["selection_rank"]] for row in rows]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )
    receipt = {
        "schema": "edgeforge-x4-selected-records/v1",
        "record_count": len(payload),
        "manifest_sha256": sha256_file(args.manifest),
        "subset_sha256": sha256_file(args.output),
        "source_files": sorted(positions),
        "privacy": "contains private selected records; bodies are never printed",
    }
    args.receipt.write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "record_count": len(payload),
        "manifest_sha256": receipt["manifest_sha256"],
        "subset_sha256": receipt["subset_sha256"],
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
