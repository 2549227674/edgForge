#!/usr/bin/env python3
"""Reconstruct X4's fixed public MMLU probes without changing their identity."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_hash(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def prompt_for_row(row: dict[str, Any]) -> str:
    answer_lines = "\n".join(
        f"{LETTERS[index]}. {choice}" for index, choice in enumerate(row["choices"])
    )
    return f"Question: {row['question']}\n{answer_lines}\nAnswer:"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--identity", type=Path, required=True)
    parser.add_argument("--mmlu-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.output.exists() or args.receipt.exists():
        raise SystemExit("refusing to overwrite public X4 probe materialization")
    identity = json.loads(args.identity.read_text(encoding="utf-8"))
    probes = identity.get("probes")
    if identity.get("probe_count") != 32 or not isinstance(probes, list) or len(probes) != 32:
        raise SystemExit("X4 public probe identity must contain 32 probes")

    from pyarrow import parquet as pq

    materialized: list[dict[str, str]] = []
    for probe in probes:
        source = args.mmlu_root / probe["subject"] / "test-00000-of-00001.parquet"
        row = pq.read_table(source).to_pylist()[int(probe["doc_id"])]
        if canonical_hash(row) != probe["source_row_sha256"]:
            raise RuntimeError(f"public probe row drift: {probe['probe_id']}")
        prompt = prompt_for_row(row)
        prompt_sha = hashlib.sha256(prompt.encode()).hexdigest()
        if prompt_sha != probe["prompt_sha256"]:
            raise RuntimeError(f"public probe prompt drift: {probe['probe_id']}")
        materialized.append({"probe_id": probe["probe_id"], "prompt": prompt})

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(materialized, ensure_ascii=False, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )
    receipt = {
        "schema": "edgeforge-x4-public-probe-materialization/v1",
        "probe_count": 32,
        "identity_sha256": sha256_file(args.identity),
        "dataset_sha256": sha256_file(args.output),
        "privacy": "public cais/mmlu prompts only",
    }
    args.receipt.write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(receipt, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
