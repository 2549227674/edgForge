#!/usr/bin/env bash
# Run one isolated X4 build->get_logits measurement with complete logs.
set -uo pipefail

if [ "$#" -ne 8 ]; then
  printf '%s\n' "usage: $0 RUN_DIR PYTHON MODEL DATASET PROBES PROBE_RECEIPT FROZEN_MANIFEST OUTPUT" >&2
  exit 64
fi

run_dir=$1
python_bin=$2
model_dir=$3
dataset=$4
probes=$5
probe_receipt=$6
frozen_manifest=$7
output=$8
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
runner="$script_dir/run_x4_logits_build.py"

for required in "$python_bin" "$model_dir" "$dataset" "$probes" "$probe_receipt" "$frozen_manifest" "$runner"; do
  if [ ! -e "$required" ]; then
    printf 'missing required X4 logits input: %s\n' "$required" >&2
    exit 66
  fi
done
if [ -e "$run_dir" ] || [ -e "$output" ]; then
  printf '%s\n' "refusing to reuse X4 logits run directory or output" >&2
  exit 73
fi
mkdir -p "$run_dir"

printf '%s\n' $'timestamp_epoch_s\tpid\tvm_rss_kib\tvm_hwm_kib\tgpu_used_mib' > "$run_dir/resource_monitor.tsv"
sample_resources() {
  sample_pid=$1
  while kill -0 "$sample_pid" 2>/dev/null; do
    sample_ts=$(date +%s.%N)
    sample_rss=$(awk '/^VmRSS:/ {print $2}' "/proc/$sample_pid/status" 2>/dev/null || true)
    sample_hwm=$(awk '/^VmHWM:/ {print $2}' "/proc/$sample_pid/status" 2>/dev/null || true)
    sample_gpu=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits 2>/dev/null | awk '{sum += $1} END {if (NR) print sum; else print "NA"}')
    printf '%s\t%s\t%s\t%s\t%s\n' "$sample_ts" "$sample_pid" "${sample_rss:-NA}" "${sample_hwm:-NA}" "${sample_gpu:-NA}" >> "$run_dir/resource_monitor.tsv"
    sleep 1
  done
}

start_epoch=$(date +%s.%N)
"$python_bin" "$runner" --model "$model_dir" --dataset "$dataset" --probes "$probes" --probe-receipt "$probe_receipt" --frozen-input-manifest "$frozen_manifest" --output "$output" --receipt "$run_dir/logits_receipt.json" > "$run_dir/stdout" 2> "$run_dir/stderr" &
build_pid=$!
sample_resources "$build_pid" &
monitor_pid=$!
wait "$build_pid"
build_exit=$?
wait "$monitor_pid" || true
end_epoch=$(date +%s.%N)

"$python_bin" - "$start_epoch" "$end_epoch" "$build_exit" "$run_dir/run_result.json" <<'PY'
import json,sys
started,ended,code,out=sys.argv[1:]
with open(out,"w",encoding="utf-8") as f:
    json.dump({"schema":"edgeforge-x4-logits-run/v1","started_epoch_s":float(started),"ended_epoch_s":float(ended),"wall_seconds":float(ended)-float(started),"exit_code":int(code)},f,indent=2,sort_keys=True)
    f.write("\n")
PY
sha256sum "$runner" "$dataset" "$probes" "$probe_receipt" "$frozen_manifest" > "$run_dir/input_sha256.txt"
if [ -f "$output" ]; then
  sha256sum "$output" > "$run_dir/logits.sha256"
fi
printf 'build_exit_code=%s\n' "$build_exit" > "$run_dir/exit_code"
exit "$build_exit"
