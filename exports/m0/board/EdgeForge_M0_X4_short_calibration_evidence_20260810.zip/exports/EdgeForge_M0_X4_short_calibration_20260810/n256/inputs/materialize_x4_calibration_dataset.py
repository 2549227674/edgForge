#!/usr/bin/env python3
"""Materialize X4's fixed private calibration dataset without reselecting it.

The input manifest is the immutable content-free X4 manifest.  This utility
looks up only its fixed source positions, re-renders the records using the
frozen Gate-7 contract, and refuses output if identity, token count, or
calibration text hash drift.  It emits the RKLLM dataset schema but never logs
or prints any private record or rendered text.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
from typing import Any


MAX_CONTEXT = 16_384


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--mix-records", type=Path)
    source.add_argument(
        "--selected-records",
        type=Path,
        help="Run-scoped private subset produced by extract_x4_selected_records.py.",
    )
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--expected-count", type=int, choices=(128, 256), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    return parser.parse_args()


def read_manifest(path: Path, expected_count: int) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as source:
        rows = list(csv.DictReader(source, delimiter="\t"))
    if len(rows) != expected_count:
        raise RuntimeError(
            f"X4 N={expected_count} manifest must contain {expected_count} rows, got {len(rows)}"
        )
    required = {
        "selection_rank", "uid", "source_file", "source_line", "rendered_sha256",
        "calibration_sha256", "calibration_tokens", "truncated_to_max_context",
        "selected_for_n128", "selected_for_n256",
    }
    if not rows or set(rows[0]) < required:
        raise RuntimeError("X4 manifest lacks required identity fields")
    if [row["selection_rank"] for row in rows] != [str(number) for number in range(1, expected_count + 1)]:
        raise RuntimeError(f"X4 manifest selection ranks are not the frozen 1..{expected_count} order")
    if len({row["uid"] for row in rows}) != expected_count:
        raise RuntimeError("X4 manifest has duplicate UIDs")
    if not all(row["selected_for_n256"] == "True" for row in rows):
        raise RuntimeError("X4 manifest membership flags are not the fixed nested selection")
    if expected_count == 128 and not all(row["selected_for_n128"] == "True" for row in rows):
        raise RuntimeError("X4 N=128 manifest membership flags are not the fixed nested selection")
    return rows


def lookup_records(mix_records: Path, rows: list[dict[str, str]]) -> dict[str, dict[str, Any]]:
    positions: dict[str, dict[int, dict[str, str]]] = {}
    for row in rows:
        positions.setdefault(row["source_file"], {})[int(row["source_line"])] = row
    records: dict[str, dict[str, Any]] = {}
    for source_name, expected_lines in positions.items():
        source_path = mix_records / source_name
        if not source_path.is_file():
            raise RuntimeError(f"X4 source file is missing: {source_path}")
        remaining = set(expected_lines)
        with source_path.open("r", encoding="utf-8") as source:
            for line_number, line in enumerate(source, 1):
                if line_number not in remaining:
                    continue
                record = json.loads(line)
                expected = expected_lines[line_number]
                if str(record.get("uid")) != expected["uid"]:
                    raise RuntimeError(
                        f"X4 source identity mismatch at {source_name}:{line_number}"
                    )
                records[expected["uid"]] = record
                remaining.remove(line_number)
                if not remaining:
                    break
        if remaining:
            raise RuntimeError(f"X4 source positions missing from {source_name}: {sorted(remaining)}")
    if len(records) != len(rows):
        raise RuntimeError("X4 did not recover every fixed record")
    return records


def load_selected_records(path: Path, rows: list[dict[str, str]]) -> list[dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, list) or len(payload) != len(rows):
        raise RuntimeError("X4 selected-record subset has the wrong length")
    records: list[dict[str, Any]] = []
    for item in payload:
        if not isinstance(item, dict) or not isinstance(item.get("record"), dict):
            raise RuntimeError("X4 selected-record subset has an invalid schema")
        records.append(item["record"])
    return records


def truncate_rendered(tokenizer: Any, rendered: str) -> tuple[str, int, bool]:
    token_ids = tokenizer(rendered, add_special_tokens=False)["input_ids"]
    if len(token_ids) <= MAX_CONTEXT:
        return rendered, len(token_ids), False
    clipped = tokenizer.decode(
        token_ids[:MAX_CONTEXT], skip_special_tokens=False, clean_up_tokenization_spaces=False
    )
    reencoded = tokenizer(clipped, add_special_tokens=False)["input_ids"]
    if len(reencoded) > MAX_CONTEXT:
        raise RuntimeError("X4 truncation round-trip exceeds the 16K cap")
    return clipped, len(reencoded), True


def main() -> int:
    args = parse_args()
    if args.output.exists() or args.receipt.exists():
        raise SystemExit("refusing to overwrite an X4 calibration output or receipt")
    rows = read_manifest(args.manifest, args.expected_count)
    if args.mix_records is not None and not args.mix_records.is_dir():
        raise SystemExit(f"mix_records directory is missing: {args.mix_records}")
    if args.selected_records is not None and not args.selected_records.is_file():
        raise SystemExit(f"selected-record subset is missing: {args.selected_records}")

    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(
        str(args.model), local_files_only=True, trust_remote_code=True
    )
    selected_records = (
        None if args.mix_records is not None else load_selected_records(args.selected_records, rows)
    )
    records = lookup_records(args.mix_records, rows) if args.mix_records is not None else None
    calibration: list[dict[str, str]] = []
    verified_hashes: list[str] = []
    token_total = 0
    for index, row in enumerate(rows):
        record = records[row["uid"]] if records is not None else selected_records[index]
        rendered = tokenizer.apply_chat_template(
            record["messages"],
            tools=record.get("tools") or None,
            tokenize=False,
            add_generation_prompt=False,
            enable_thinking=True,
            preserve_thinking=True,
        )
        clipped, token_count, truncated = truncate_rendered(tokenizer, rendered)
        calibration_hash = sha256_bytes(clipped.encode("utf-8"))
        calibration.append({"input": clipped, "target": ""})
        verified_hashes.append(calibration_hash)
        token_total += token_count
        if truncated:
            raise RuntimeError("X4 selected calibration unexpectedly requires truncation")

    expected_tokens = {128: 105_865, 256: 211_725}[args.expected_count]
    if token_total != expected_tokens:
        raise RuntimeError(
            f"X4 N={args.expected_count} token total mismatch: {token_total} != {expected_tokens}"
        )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(calibration, ensure_ascii=False, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )
    receipt = {
        "schema": "edgeforge-x4-calibration-materialization/v1",
        "N": args.expected_count,
        "record_count": len(calibration),
        "token_total": token_total,
        "truncated_count": 0,
        "manifest": str(args.manifest),
        "manifest_sha256": sha256_file(args.manifest),
        "dataset": str(args.output),
        "dataset_sha256": sha256_file(args.output),
        "calibration_sha256_in_selection_order": verified_hashes,
        "dataset_schema": "list[{input: rendered_calibration_text, target: empty_string}]",
        "privacy": "private calibration bodies were materialized but are not printed by this utility",
        "source_mode": "mix_records" if args.mix_records is not None else "run_scoped_selected_records",
    }
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    args.receipt.write_text(json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "record_count": len(calibration),
        "token_total": token_total,
        "truncated_count": 0,
        "dataset_sha256": receipt["dataset_sha256"],
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
