#!/usr/bin/env python3
"""Build one X4 calibration arm and capture 32 final-token float32 logits."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import sys
import traceback
from pathlib import Path

import numpy as np

from rkllm_input_identity import sha256, verify_frozen_input


def emit(event: str, **payload: object) -> None:
    print(json.dumps({"event": event, **payload}, ensure_ascii=False), flush=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--probes", type=Path, required=True)
    parser.add_argument("--probe-receipt", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("--frozen-input-manifest", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    for path in (args.dataset, args.probes, args.probe_receipt):
        if not path.is_file():
            raise SystemExit(f"missing X4 logits input: {path}")
    if args.output.exists() or args.receipt.exists():
        raise SystemExit("refusing to overwrite X4 logits output")

    identity = verify_frozen_input(args.model, manifest_path=args.frozen_input_manifest)
    probes = json.loads(args.probes.read_text(encoding="utf-8"))
    probe_receipt = json.loads(args.probe_receipt.read_text(encoding="utf-8"))
    if not isinstance(probes, list) or len(probes) != 32:
        raise SystemExit("X4 logits runner requires exactly 32 public probes")
    if probe_receipt.get("probe_count") != 32 or probe_receipt.get("dataset_sha256") != sha256(args.probes):
        raise SystemExit("X4 public probe receipt does not bind the prompt file")
    probe_ids = [item.get("probe_id") for item in probes]
    if len(set(probe_ids)) != 32 or any(not isinstance(item.get("prompt"), str) for item in probes):
        raise SystemExit("X4 public probe schema or identity is invalid")

    emit(
        "provenance",
        python=sys.version.split()[0],
        platform=platform.platform(),
        working_directory=str(Path.cwd()),
        TMPDIR=os.environ.get("TMPDIR"),
        model=str(args.model),
        input_identity=identity,
        calibration_dataset=str(args.dataset),
        calibration_sha256=sha256(args.dataset),
        public_probes_sha256=sha256(args.probes),
        quantized_dtype="w8a8",
        target_platform="RK3588",
        max_context=16384,
        num_npu_core=1,
        device="cuda",
        dtype="bfloat16",
    )

    import torch
    from rkllm.api import RKLLM
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(
        str(args.model), local_files_only=True, trust_remote_code=True
    )
    llm = RKLLM()
    load_result = llm.load_huggingface(
        model=str(args.model), model_lora=None, device="cuda", dtype="bfloat16",
        custom_config=None, load_weight=True,
    )
    emit("load_huggingface", result=load_result)
    if load_result != 0:
        return 1
    build_result = llm.build(
        do_quantization=True,
        optimization_level=1,
        quantized_dtype="w8a8",
        quantized_algorithm="normal",
        target_platform="RK3588",
        num_npu_core=1,
        extra_qparams=None,
        dataset=str(args.dataset),
        hybrid_rate=0,
        max_context=16384,
    )
    emit("build", result=build_result)
    if build_result != 0:
        return 1

    rows: list[np.ndarray] = []
    argmax: list[int] = []
    for index, probe in enumerate(probes, 1):
        input_ids = tokenizer(probe["prompt"], return_tensors="pt")["input_ids"]
        logits = llm.get_logits({"input_ids": input_ids})
        if logits is None or not isinstance(logits, torch.Tensor):
            raise RuntimeError(f"get_logits failed for public probe {index}")
        stable = logits.detach().float().cpu()
        if stable.ndim != 3 or stable.shape[0] != 1:
            raise RuntimeError(f"unexpected logits shape for public probe {index}: {tuple(stable.shape)}")
        last = stable[0, -1, :].contiguous().numpy().astype(np.float32, copy=False)
        if not np.isfinite(last).all():
            raise RuntimeError(f"non-finite logits for public probe {index}")
        rows.append(last.copy())
        argmax.append(int(last.argmax()))
        emit("probe", index=index, probe_id=probe["probe_id"], vocab_size=int(last.shape[0]), argmax=argmax[-1])
        del logits, stable, last, input_ids

    matrix = np.stack(rows).astype(np.float32, copy=False)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez(args.output, probe_id=np.asarray(probe_ids), logits=matrix)
    output_sha = sha256(args.output)
    receipt = {
        "schema": "edgeforge-x4-logits/v1",
        "probe_count": 32,
        "dtype": "float32",
        "shape": list(matrix.shape),
        "argmax": argmax,
        "dataset_sha256": sha256(args.dataset),
        "probe_dataset_sha256": sha256(args.probes),
        "output_sha256": output_sha,
        "logits_bytes_sha256": hashlib.sha256(matrix.tobytes()).hexdigest(),
        "contract": {"quantized_dtype": "w8a8", "target_platform": "RK3588", "max_context": 16384, "num_npu_core": 1},
    }
    args.receipt.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    emit("logits_complete", output=str(args.output), output_sha256=output_sha, shape=list(matrix.shape))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as exc:
        emit("exception", exception_type=type(exc).__name__, message=str(exc))
        traceback.print_exc()
        raise SystemExit(1)
