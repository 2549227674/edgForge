# EdgeForge M0 X2 — `iommu_domain_id` 第 4 笔改写（2026-08-09）

## 判定

**不安全，X2 关闭。** 在 1-core、同一 W8A8 16K 工件、同一五题贪心输入下，仅将 `DRM_IOCTL_RKNPU_MEM_CREATE`（`0xC0306442`）进程内第 4 笔请求的 `iommu_domain_id` 从 `0` 改为 `1`。完整 raw transcript 的逐字节回归失败，故按 R1.7 红线立即停止；**未运行 2-core 或 3-core**。

这使 U3 按预声明判据闭合为“需同时可见”，X2 的用户态 shim 路线和后续驱动路线均不得采用。虽然进程退出码为 0、UTF-8 有效、未见 `[PAD]` 或替换字符，但这些不替代逐字节安全门禁。

## 最小改写与审计

- 仅拦截 request `0xC0306442`；shim 对第 1–3、5–8 笔不改写。
- 第 4 笔审计记录：`input_iommu_domain_id=0`、`effective_iommu_domain_id=1`、`output_iommu_domain_id=1`，请求 `178,782,208 B`、flags `0x00000403`、core mask `0x00000001`。
- shim source SHA-256：`41cdaed36f98b656407f7f6964d52c880f28abe54a1bbe125fe915828f473eb5`
- AArch64 shim SHA-256：`d3b3dcd796d0a43180a471063fdf4ff9ad506a07afc8e51c5d390d369973c8b2`

## 1-core 门禁结果

| 项 | 既有基线 | X2 改写运行 |
|---|---:|---:|
| raw transcript SHA-256 | `79040cbf92de36c230b4f7b9b61cc54f6113f0a5d94a6cb55cb802590d642630` | `1a2f41d832ada5f0799428690345c1d37216891f4704d54cbdbe61ad03851364` |
| raw transcript 字节数 | 2,087 | 4,083 |
| 首个不同字节（1-based） | — | 940 |
| `cmp` | — | exit 1 / `DIFFERENT` |
| demo exit | 基线已知 0 | 0 |
| UTF-8 / `[PAD]` / replacement character | 已通过 | `1` / `0` / `0` |

## 身份、板端状态与回滚

- boot id：`91368c69-6c37-4d37-aba8-b1e578cc6619`；运行前后未变化。
- 运行前：`MemAvailable=15,829,852 kB`、`CmaTotal=131,072 kB`、`CmaFree=28,276 kB`。回滚核验：`MemAvailable=15,767,056 kB`、`CmaTotal=131,072 kB`、`CmaFree=109,896 kB`。
- 1-core artifact：11,687,037,412 B，SHA-256 `4bdad6bfa34e23562d65c86ad1fcc68c626c6eb6f2761b4d354f26f6d7edb10b`。
- 3-core artifact：11,767,487,820 B，SHA-256 `05c0e5cc188b675dca3f5ad5ca5bf9682d332266862885c3a26c11353dad0dfe`；仅被只读哈希，未执行。
- `llm_demo` SHA-256：`f3560e779732309b55f2874a5619b0ed64c7f92e27c83931ad6df9d56c4e09b7`。
- 预加载只作为该进程的 `LD_PRELOAD` 环境变量；回滚时无活动 demo/timeout 进程、`/etc/ld.so.preload` 不存在，且工件 size/mtime 未变。未改驱动、DT、内核、CMA、artifact 或共享脚本。

`raw_board/` 含完整板端原始日志（运行前后 dmesg、boot/CMA/MemAvailable、compile、完整 stdout/stderr、ioctl、哈希和回滚状态）。
