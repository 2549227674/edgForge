#define _GNU_SOURCE

#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#define DRM_IOCTL_RKNPU_MEM_CREATE 0xC0306442UL
#define DRM_IOCTL_RKNPU_MEM_DESTROY 0xC0106444UL

struct rknpu_mem_create {
    uint32_t handle;
    uint32_t flags;
    uint64_t size;
    uint64_t obj_addr;
    uint64_t dma_addr;
    uint64_t sram_size;
    int32_t iommu_domain_id;
    uint32_t core_mask;
};

struct rknpu_mem_destroy {
    uint32_t handle;
    uint32_t reserved;
    uint64_t obj_addr;
};

_Static_assert(sizeof(struct rknpu_mem_create) == 48, "unexpected create ABI");
_Static_assert(sizeof(struct rknpu_mem_destroy) == 16, "unexpected destroy ABI");

typedef int (*ioctl_fn)(int, unsigned long, ...);

static ioctl_fn real_ioctl;
static int log_fd = -2;
static unsigned int mem_create_ordinal;

static uint64_t mono_ns(void) {
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) {
        return 0;
    }
    return (uint64_t)now.tv_sec * 1000000000ULL + (uint64_t)now.tv_nsec;
}

static int get_log_fd(void) {
    const char *path;
    if (log_fd != -2) {
        return log_fd;
    }
    path = getenv("P7_IOCTL_LOG");
    if (path == NULL || *path == '\0') {
        log_fd = -1;
        return log_fd;
    }
    log_fd = open(path, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0600);
    return log_fd;
}

static void emit_line(const char *line, size_t length) {
    int fd = get_log_fd();
    if (fd >= 0) {
        (void)syscall(SYS_write, fd, line, length);
    }
}

static void log_create(int fd, unsigned int ordinal, int rewrite_applied,
                       const struct rknpu_mem_create *input,
                       const struct rknpu_mem_create *effective,
                       const struct rknpu_mem_create *output, int rc,
                       int saved_errno) {
    char line[1280];
    int length = snprintf(
        line, sizeof(line),
        "event=mem_create ts_mono_ns=%llu pid=%ld fd=%d request=0x%08lx "
        "create_ordinal=%u x2_rewrite_applied=%d "
        "input_handle=%u input_flags=0x%08x input_size=%llu "
        "input_obj_addr=0x%016llx input_dma_addr=0x%016llx "
        "input_sram_size=%llu input_iommu_domain_id=%d input_core_mask=0x%08x "
        "effective_iommu_domain_id=%d rc=%d errno=%d output_handle=%u "
        "output_size=%llu output_obj_addr=0x%016llx "
        "output_dma_addr=0x%016llx output_sram_size=%llu "
        "output_iommu_domain_id=%d output_core_mask=0x%08x\n",
        (unsigned long long)mono_ns(), (long)getpid(), fd,
        DRM_IOCTL_RKNPU_MEM_CREATE, ordinal, rewrite_applied, input->handle,
        input->flags, (unsigned long long)input->size,
        (unsigned long long)input->obj_addr, (unsigned long long)input->dma_addr,
        (unsigned long long)input->sram_size, input->iommu_domain_id,
        input->core_mask, effective->iommu_domain_id, rc, saved_errno,
        output->handle, (unsigned long long)output->size,
        (unsigned long long)output->obj_addr, (unsigned long long)output->dma_addr,
        (unsigned long long)output->sram_size, output->iommu_domain_id,
        output->core_mask);
    if (length > 0) {
        emit_line(line, (size_t)length < sizeof(line) ? (size_t)length : sizeof(line));
    }
}

static void log_destroy(int fd, const struct rknpu_mem_destroy *before,
                        const struct rknpu_mem_destroy *after, int rc,
                        int saved_errno) {
    char line[512];
    int length = snprintf(
        line, sizeof(line),
        "event=mem_destroy ts_mono_ns=%llu pid=%ld fd=%d request=0x%08lx "
        "input_handle=%u input_obj_addr=0x%016llx rc=%d errno=%d "
        "output_handle=%u output_obj_addr=0x%016llx\n",
        (unsigned long long)mono_ns(), (long)getpid(), fd,
        DRM_IOCTL_RKNPU_MEM_DESTROY, before->handle,
        (unsigned long long)before->obj_addr, rc, saved_errno, after->handle,
        (unsigned long long)after->obj_addr);
    if (length > 0) {
        emit_line(line, (size_t)length < sizeof(line) ? (size_t)length : sizeof(line));
    }
}

int ioctl(int fd, unsigned long request, ...) {
    void *arg;
    va_list args;
    int rc;
    int saved_errno;

    if (real_ioctl == NULL) {
        *(void **)(&real_ioctl) = dlsym(RTLD_NEXT, "ioctl");
        if (real_ioctl == NULL) {
            errno = ENOSYS;
            return -1;
        }
    }

    va_start(args, request);
    arg = va_arg(args, void *);
    va_end(args);

    if (request == DRM_IOCTL_RKNPU_MEM_CREATE && arg != NULL) {
        struct rknpu_mem_create input;
        struct rknpu_mem_create effective;
        struct rknpu_mem_create output;
        unsigned int ordinal;
        int rewrite_applied = 0;

        memcpy(&input, arg, sizeof(input));
        ordinal = ++mem_create_ordinal;
        if (ordinal == 4 && input.iommu_domain_id == 0) {
            ((struct rknpu_mem_create *)arg)->iommu_domain_id = 1;
            rewrite_applied = 1;
        }
        memcpy(&effective, arg, sizeof(effective));
        rc = real_ioctl(fd, request, arg);
        saved_errno = errno;
        memcpy(&output, arg, sizeof(output));
        log_create(fd, ordinal, rewrite_applied, &input, &effective, &output, rc,
                   saved_errno);
        errno = saved_errno;
        return rc;
    }

    if (request == DRM_IOCTL_RKNPU_MEM_DESTROY && arg != NULL) {
        struct rknpu_mem_destroy before;
        struct rknpu_mem_destroy after;
        memcpy(&before, arg, sizeof(before));
        rc = real_ioctl(fd, request, arg);
        saved_errno = errno;
        memcpy(&after, arg, sizeof(after));
        log_destroy(fd, &before, &after, rc, saved_errno);
        errno = saved_errno;
        return rc;
    }

    return real_ioctl(fd, request, arg);
}
