# EdgeForge M0 X5 evidence

This directory contains only small, auditable evidence for X5/U6:

- `cloud_logs/`: isolated-input preflight, RKLLM build/export events, artifact hashes, and xdelta transfer logs.
- `board_logs/edgeforge_x5/`: board-side decode hashes, parser-probe stdout/stderr, exit codes, and exact warning counts.

Large `.rkllm` artifacts are intentionally excluded. The result and conclusion are frozen in `docs/m0/06_board_smoke.md` §4.3.
