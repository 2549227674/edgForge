#!/usr/bin/env bash
set -u

model=${1:?usage: run_x5_board_parser_probe.sh MODEL LOG_DIR}
log_dir=${2:?usage: run_x5_board_parser_probe.sh MODEL LOG_DIR}
demo=${RKLLM_DEMO_PATH:-/home/orangepi/rknn-llm/examples/rkllm_api_demo/deploy/build-native-v1.3.0/llm_demo}

mkdir -p "$log_dir"
printf '%s\n' 'Reply with OK.' 'exit' \
  | timeout 900 "$demo" "$model" 8 16384 \
      >"$log_dir/board.stdout" 2>"$log_dir/board.stderr"
rc=${PIPESTATUS[1]}
printf '%s\n' "$rc" >"$log_dir/board.exit_code"
{
  grep -F 'Failed to parse chat_template' "$log_dir/board.stdout" || true
  grep -F 'Failed to parse chat_template' "$log_dir/board.stderr" || true
} >"$log_dir/parser_warning.txt"
wc -l <"$log_dir/parser_warning.txt" >"$log_dir/parser_warning_count"
exit "$rc"
