#!/usr/bin/env bash
set -u

variant_id=${1:?usage: run_x5_board_from_xdelta.sh VARIANT_ID EXPECTED_SHA256}
expected_sha256=${2:?usage: run_x5_board_from_xdelta.sh VARIANT_ID EXPECTED_SHA256}
run_id="x5_20260809__${variant_id}__w8a8__rk3588__16k__1core"
base=/home/orangepi/edgeforge_x5
baseline=/home/orangepi/edgeforge_m0_smoke_20260807/artifacts/gemma-4-e4b-it-w8a8-rk3588-16k-1core.rkllm
patch="$base/$run_id.rkllm.from_baseline.xdelta"
decoded="$base/$run_id.decoded.rkllm"
model="$base/$run_id.rkllm"
log_dir="$base/$run_id.logs"

xdelta3 -d -f -s "$baseline" "$patch" "$decoded" \
  >"$base/$run_id.xdelta_decode.stdout" \
  2>"$base/$run_id.xdelta_decode.stderr"
decode_rc=$?
printf '%s\n' "$decode_rc" >"$base/$run_id.xdelta_decode.exit_code"
if (( decode_rc != 0 )); then
  exit "$decode_rc"
fi

actual_sha256=$(sha256sum "$decoded" | awk '{print $1}')
printf '%s  %s\n' "$actual_sha256" "$decoded" >"$base/$run_id.sha256"
if [[ "$actual_sha256" != "$expected_sha256" ]]; then
  printf 'artifact SHA mismatch: expected=%s actual=%s\n' \
    "$expected_sha256" "$actual_sha256" \
    >"$base/$run_id.sha256.stderr"
  exit 3
fi
mv -f "$decoded" "$model"

"$base/run_x5_board_parser_probe.sh" "$model" "$log_dir"
