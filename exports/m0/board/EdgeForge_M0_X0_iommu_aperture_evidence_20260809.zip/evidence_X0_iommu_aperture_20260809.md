# X0 · IOMMU aperture 只读探针证据

- 采集日期：2026-08-09
- 板端：`orangepi@192.168.137.66`，以 `sudo` root 只读执行
- boot id：`91368c69-6c37-4d37-aba8-b1e578cc6619`
- 内核：`6.1.99-rockchip-rk3588`（aarch64）
- 写入操作：**无**。未修改驱动、device-tree、内核参数、启动配置或工件。

## 采集命令

以 root 执行以下只读族：

```bash
id; uname -a; cat /proc/sys/kernel/random/boot_id
ls -la /sys/kernel/iommu_groups/
cat /sys/kernel/debug/iommu/* 2>/dev/null
dmesg | grep -iE 'iommu|aperture|rknpu'
find /proc/device-tree -name '*iommu*'
find /sys/firmware/devicetree/base -maxdepth 6 \
  \( -iname '*iommu*' -o -name iommus -o -name dma-ranges \) -print
od -An -tx1 /sys/firmware/devicetree/base/npu@fdab0000/iommus
find /sys -type f \( -iname '*aperture*' -o -iname '*geometry*' \) -print
grep -E 'CONFIG_(IOMMU|ROCKCHIP_IOMMU)' /boot/config-$(uname -r)
```

## 原始关键输出

```text
uid=0(root) gid=0(root) groups=0(root)
RKNPU fdab0000.npu: Adding to iommu group 0
RKNPU fdab0000.npu: RKNPU: rknpu iommu is enabled, using iommu mode

/sys/kernel/iommu_groups/0/devices/fdab0000.npu ->
  ../../../../devices/platform/fdab0000.npu
/sys/kernel/iommu_groups/0/type
DMA

/sys/firmware/devicetree/base/npu@fdab0000/iommus
  00 00 00 bb

/sys/firmware/devicetree/base/iommu@fdab9000/compatible
  72 6f 63 6b 63 68 69 70 2c 69 6f 6d 6d 75 2d 76 32 00
  # UTF-8: rockchip,iommu-v2
/sys/firmware/devicetree/base/iommu@fdab9000/#iommu-cells
  00 00 00 00
/sys/firmware/devicetree/base/iommu@fdab9000/phandle
  00 00 00 bb
/sys/firmware/devicetree/base/iommu@fdab9000/status
  6f 6b 61 79 00
  # UTF-8: okay

# CONFIG_IOMMU_DEBUGFS is not set
CONFIG_ROCKCHIP_IOMMU=y
CONFIG_IOMMU_IOVA=y
```

补充观测：`/sys/kernel/debug/iommu` 不存在；`/sys/kernel/debug/rknpu/` 只有频率、负载、电压、复位等节点，无 aperture 节点；NPU 与其 IOMMU 节点均无 `dma-ranges` 属性；全 `/sys` 文件名搜索没有 `*aperture*` 或 `*geometry*` 导出。板端没有可读的 `rockchip-iommu.c` 源码副本。

## 判定

**X0 已执行，结果为「无可读 aperture 节点」。** 本次只验证了 NPU 已连接并使用 Rockchip IOMMU，不能在运行时直接读出 IOVA aperture，更不能证明其页表索引位宽是不可修改的硬件限制。

因此 U15 保持未闭合：4 GiB 仍是 P1 页对齐 map 行为所支持的 domain 容量观察，不升格为「已确认的硬件页表格式」。扩大 domain 的驱动/device-tree 路线不获授权；X2 的用户态 domain 落点判别器不受影响。
