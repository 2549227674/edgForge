# X1 · W4A16 / 3-core build-only 探针证据

- 采集日期：2026-08-09
- 云端：RKLLM Toolkit 1.3.0，Python 3.12.3，CUDA 设备 NVIDIA GeForce RTX 4090
- 参数：`target_platform=RK3588`、`num_npu_core=3`、`quantized_dtype=w4a16`、`quantized_algorithm=normal`、`max_context=16384`、`hybrid_rate=0`、`device=cuda`、`dtype=bfloat16`
- 校准集：官方 19 条 `data_quant.json`，SHA-256 `f0433b1c416d11801ce49ece1a8eb84ec53657685ed1929d45de6dd75c134478`
- 执行模式：`--build-only`。没有调用 `export_rkllm`，没有生成 W4A16 工件、没有传板、没有运行 P7 shim、S2a/S2c 或 PC 质量对照。

## 输入身份护栏

第一次尝试在加载阶段发现当前云端原模型目录的 `chat_template.jinja` / `tokenizer_config.json` 分别为 `a13a…` / `21a6…`，与冻结 W8A8 基线的 `0a2c…` / `90c3…` 不同。该尝试在 `build()` 前中止，不能作为支持性结论。

有效尝试使用独立输入目录：仅将当前模型的其余文件符号链接进去，并从保留的 `template_B_unchanged` 副本复制两份冻结模板文件；未修改原模型目录。有效输入的七个源文件哈希均与 W8A8 基线记录一致：

| 文件 | SHA-256 |
|---|---|
| `chat_template.jinja` | `0a2c8073c878ab1da004bee933a998606537bbb62016310352c7285c3f01c5b5` |
| `config.json` | `33b10c02df3c2e8536cf323d29d53262aaa2f4d11dbe19bc729373fbe90295d4` |
| `generation_config.json` | `d4226bbe3117d2d253ba4609720ba82c6c4ce4627a9a6ae05387c78983ac03de` |
| `model.safetensors` | `cfbd3d2f1cd71bd471c37fe2bf8546d5028d41e5736f64e1ca6c6b8893125503` |
| `processor_config.json` | `32bdf45d2ad4cc29a0822ddd157a182de76644f0419a6228d151495256e9813c` |
| `tokenizer.json` | `cc8d3a0ce36466ccc1278bf987df5f71db1719b9ca6b4118264f45cb627bfe0f` |
| `tokenizer_config.json` | `90c3a3ba5bf53818383a58e1a776cbcacd2a038d4812eaa373e1522f2d06f3df` |

## 有效探针输出

```text
load_huggingface result=0
ERROR: target_platform: rk3588 not support quantized_dtype: w4a16!
build result=-1
process exit code=1
```

## 判定

**U13 已闭合：在 RKLLM Toolkit 1.3.0 / RK3588 上，`w4a16` 不受支持。X1 按预先声明的步 1 判据关闭。** 步 1 已明确拒绝，故不导出工件、不传板，也不尝试 `w4a16_g*` 阶梯；这些变体没有获得「支持」的结论。

U14 没有测量值：这是因为不存在可上板的 W4A16 工件，而非观测到激活缓冲不翻倍。X6 的前置因此不满足。当前多核交付路线只余 X2；未来须在厂商提供支持 W4A16 的 toolkit/runtime 后，以新的 artifact 身份重新执行 X1。

## 补充 · RK3588 `quantized_dtype` build-only 矩阵

用户要求后，以完全相同的冻结输入、官方 19 条校准集、3-core / 16K / `cuda+bfloat16` 合同逐项探测受控脚本所列的 8 个 `quantized_dtype`。每项均验证七个源文件 SHA-256 与上表一致；全部为 `--build-only`，没有导出工件。

| `quantized_dtype` | `build()` | 结论 |
|---|---:|---|
| `w4a16` | −1 | RK3588 不支持 |
| `w4a16_g32` | −1 | RK3588 不支持 |
| `w4a16_g64` | −1 | RK3588 不支持 |
| `w4a16_g128` | −1 | RK3588 不支持 |
| `w8a8` | 0 | 本组合可 build |
| `w8a8_g128` | 0 | 本组合可 build |
| `w8a8_g256` | 0 | 本组合可 build |
| `w8a8_g512` | −1 | E4B tensor shape 不能被 group size 512 整除 |

W4 四项的原文均为 `target_platform: rk3588 not support quantized_dtype: <dtype>!`。`w8a8_g512` 的原文为 `The tensor shape of this model can not be evenly divided into group_size[512]`；这只说明该 E4B 工件无法用该分组，不能升格为通用 RK3588 平台不支持的结论。

即使 `w8a8_g128/g256` 可 build，也不能作为多核容量解法：scale 元数据会增加而非减少 domain 0 占用。该矩阵只回答 build 支持性，不证明板端 init、质量或 3-core 可行性。

## 原始文件

本地保留的有效云端原始文件在 `exports/EdgeForge_M0_X1_w4a16_3core_probe_20260809/cloud_effective/`：

| 文件 | SHA-256 |
|---|---|
| `build_only.log` | `6f90964e0db3df44eabf27457de324b1bca1d391b03221722667ecd5af84ab85` |
| `build_only.exit_code` | `4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865` |
| `run_contract.log` | `3d6fe2b633b87744de562c5a140dd7c74d556d4b786473f62f1901fe929f9638` |

受控转换脚本 SHA-256 为 `e4faa13ed35787784ea9dc6d6dbd2c1ca9ac62d1f718444b0e1046a14625dfba`，与本仓库 `scripts/convert_gemma4_e4b_rkllm_smoke.py` 一致。

补充矩阵的原始目录是 `exports/EdgeForge_M0_X1_w4a16_3core_probe_20260809/cloud_matrix/`；`run_contract.log` SHA-256 为 `61c078011a23c6b8434a940bef2316cac7d40fef04cf1da489d8b86302b96ec9`，`matrix_runner.log` SHA-256 为 `1f9f3ed1bb95268983fca73747ea1f8cb89d4509213e48321eca2e9b5b7c091b`。
