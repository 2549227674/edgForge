#!/usr/bin/env python3
"""Convert the frozen Gemma 4 E4B HF checkpoint to an RKLLM smoke artifact.

The default is the frozen RK3588 W8A8 baseline.  The explicitly enumerated
``--quantized-dtype`` values also support X1 format probes without mutating the
baseline recipe.  This is not an M2 performance run.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
import traceback
from pathlib import Path


MAX_CONTEXT_LIMIT = 16_384  # RKLLM SDK 1.3.0, table 3-3.
QUANTIZED_DTYPES = (
    "w4a16",
    "w4a16_g32",
    "w4a16_g64",
    "w4a16_g128",
    "w8a8",
    "w8a8_g128",
    "w8a8_g256",
    "w8a8_g512",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def emit(event: str, **payload: object) -> None:
    print(json.dumps({"event": event, **payload}, ensure_ascii=False), flush=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument(
        "--output",
        type=Path,
        help="Destination artifact; required unless --load-only or --build-only is selected.",
    )
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument(
        "--dtype", choices=("float32", "float16", "bfloat16"), default="bfloat16"
    )
    parser.add_argument("--max-context", type=int, default=MAX_CONTEXT_LIMIT)
    parser.add_argument(
        "--num-npu-core",
        type=int,
        choices=(1, 2, 3),
        default=3,
        help="RK3588 NPU core count compiled into the RKLLM artifact.",
    )
    parser.add_argument(
        "--quantized-dtype",
        choices=QUANTIZED_DTYPES,
        default="w8a8",
        help="RKLLM quantized_dtype; defaults to the frozen W8A8 baseline.",
    )
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--load-only",
        action="store_true",
        help="Parse the HF checkpoint without loading weights or running conversion.",
    )
    mode.add_argument(
        "--build-only",
        action="store_true",
        help="Stop after build(); use for a format-support probe before export.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.output is None and not (args.load_only or args.build_only):
        raise SystemExit("--output is required unless --load-only or --build-only is selected")
    if not args.model.is_dir():
        raise SystemExit(f"Model directory does not exist: {args.model}")
    if not args.dataset.is_file():
        raise SystemExit(f"Calibration dataset does not exist: {args.dataset}")
    if args.max_context <= 0 or args.max_context > MAX_CONTEXT_LIMIT:
        raise SystemExit(
            f"max_context must be in 1..{MAX_CONTEXT_LIMIT}; got {args.max_context}"
        )
    if args.max_context % 32:
        raise SystemExit("max_context must be aligned to 32")

    config_path = args.model / "config.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    source_files = [
        item
        for item in sorted(args.model.iterdir())
        if item.is_file() and item.name not in {"README", "README.md"}
    ]
    emit(
        "provenance",
        python=sys.version.split()[0],
        platform=platform.platform(),
        model=str(args.model),
        model_type=config.get("model_type"),
        architectures=config.get("architectures"),
        source_sha256={item.name: sha256(item) for item in source_files},
        calibration_dataset=str(args.dataset),
        calibration_sha256=sha256(args.dataset),
        target_platform="RK3588",
        quantized_dtype=args.quantized_dtype,
        quantized_algorithm="normal",
        optimization_level=1,
        num_npu_core=args.num_npu_core,
        hybrid_rate=0,
        max_context=args.max_context,
        device=args.device,
        dtype=args.dtype,
        load_only=args.load_only,
        build_only=args.build_only,
    )

    from rkllm.api import RKLLM

    llm = RKLLM()
    load_result = llm.load_huggingface(
        model=str(args.model),
        model_lora=None,
        device=args.device,
        dtype=args.dtype,
        custom_config=None,
        load_weight=not args.load_only,
    )
    emit("load_huggingface", result=load_result)
    if load_result != 0:
        return 1
    if args.load_only:
        return 0

    build_result = llm.build(
        do_quantization=True,
        optimization_level=1,
        quantized_dtype=args.quantized_dtype,
        quantized_algorithm="normal",
        target_platform="RK3588",
        num_npu_core=args.num_npu_core,
        extra_qparams=None,
        dataset=str(args.dataset),
        hybrid_rate=0,
        max_context=args.max_context,
    )
    emit("build", result=build_result)
    if build_result != 0:
        return 1
    if args.build_only:
        emit("build_only_complete", quantized_dtype=args.quantized_dtype)
        return 0

    args.output.parent.mkdir(parents=True, exist_ok=True)
    export_result = llm.export_rkllm(str(args.output))
    emit("export_rkllm", result=export_result, output=str(args.output))
    if export_result != 0:
        return 1
    emit("artifact", size_bytes=args.output.stat().st_size, sha256=sha256(args.output))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as exc:  # The exception and traceback are evidence on failure.
        emit("exception", exception_type=type(exc).__name__, message=str(exc))
        traceback.print_exc()
        raise SystemExit(1)
